import{j as s}from"./vendor-0b38e451.js";const o=({children:r})=>s.jsx("div",{className:"grid grid-cols-[1fr,400px] gap-8",children:r});export{o as A};
//# sourceMappingURL=ApprovalCardLayout-728c7aa9.js.map
