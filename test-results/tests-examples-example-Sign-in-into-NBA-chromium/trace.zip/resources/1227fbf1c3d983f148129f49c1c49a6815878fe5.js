import{aQ as a,j as r}from"./vendor-0b38e451.js";import{m as n}from"./index-b958f550.js";const c=o=>{const t=a();return r.jsx(n,{role:"link",color:"secondary",onClick:()=>t(-1),...o,children:"Back"})};export{c as B};
//# sourceMappingURL=BackButton-b7024e73.js.map
