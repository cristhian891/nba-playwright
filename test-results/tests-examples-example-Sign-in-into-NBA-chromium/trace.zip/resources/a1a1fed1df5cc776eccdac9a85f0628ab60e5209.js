const s="en-GB",t="https://mobius-jira.bt.com";export{s as A,t as J};
//# sourceMappingURL=app-c776eab1.js.map
