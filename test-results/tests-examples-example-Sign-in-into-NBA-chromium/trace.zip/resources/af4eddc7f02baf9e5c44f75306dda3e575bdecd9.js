import{r as e,j as t}from"./vendor-0b38e451.js";import{I as o,G as a}from"./date-fns-fc5b990f.js";const n="PPpp",p=r=>typeof r=="string"?a(r):r,m=e.memo(function({date:s}){return t.jsx(t.Fragment,{children:o(p(s),n)})});export{m as D};
//# sourceMappingURL=DateDisplay-23b4c992.js.map
