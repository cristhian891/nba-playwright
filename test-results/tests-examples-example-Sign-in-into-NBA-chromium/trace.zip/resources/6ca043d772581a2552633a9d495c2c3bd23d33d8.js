import{r as t,j as e,aH as r}from"./vendor-0b38e451.js";import{ei as i,aR as m}from"./index-b958f550.js";const c=({to:a,params:o,onNavigate:s=m})=>(t.useEffect(()=>s()),e.jsx(r,{to:i(a,o)}));export{c as N};
//# sourceMappingURL=NavigateEncoded-bfb55ae5.js.map
