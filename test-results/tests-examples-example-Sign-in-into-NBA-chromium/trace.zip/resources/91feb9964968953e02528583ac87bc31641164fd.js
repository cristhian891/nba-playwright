import{j as r}from"./vendor-0b38e451.js";const o=({datetime:e,...t})=>r.jsx("time",{...t,children:new Date(e).toLocaleString("en")});export{o as T};
//# sourceMappingURL=Time-1bbee855.js.map
