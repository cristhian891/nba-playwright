import{r as o}from"./vendor-0b38e451.js";import{e as u,f7 as c}from"./index-b958f550.js";const a=e=>e.every(r=>r!==void 0),t=e=>e.reduce((r,s,d,i)=>(e.length===2?r[s]=e[1]:r[s]=t(i.slice(1)),r),{}),n=e=>{const r=u();o.useEffect(()=>{a(e)&&r(c.actions.setBreadcrumbs(t(e)))},[r,e])};export{n as u};
//# sourceMappingURL=useBreadcrumbs-f37979ea.js.map
